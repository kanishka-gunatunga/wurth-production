@extends('finance::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>Module: {!! config('finance.name') !!}</p>
@endsection
